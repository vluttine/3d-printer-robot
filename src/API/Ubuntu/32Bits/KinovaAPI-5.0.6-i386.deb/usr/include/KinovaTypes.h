/**
 * @file KinovaTypes.h
 * @brief This file contains all data structures and all data type(enum and typedef) that you'll need to use this API.
 */
#pragma once

/**
 * @brief Size of the @link ControlsModeMap @endlink array in the structure @link JoystickCommand @endlink.
 */
#define JOYSTICK_BUTTON_COUNT 16

/**
 * @brief Max size of the advance retract trajectory that is stored in the @link ClientConfigurations @endlink.
 */
#define NB_ADVANCE_RETRACT_POSITION		20

/**
 * @brief This is the size of the data array stored in a @link SystemError @endlink object.
 */
#define ERROR_DATA_COUNT_MAX 	50

/**
 * @brief The robot's firmware has several software layers. This describes how many layer there is in the firmware.
 */
#define ERROR_LAYER_COUNT 7

/**
 * @brief This represents the max count of protection zones that can be stored in the robot's memory.
 */
#define LEGACY_CONFIG_NB_ZONES_MAX		10

/**
 * @brief This is the size of the array Points in a @link ZoneShape @endlink .
 */
#define LEGACY_CONFIG_NB_POINTS_COUNT   8

/**
 * @brief This is the size of the array Mapping contained in the structure @link ControlMappingCharts @endlink .
 */
#define CONTROL_MAPPING_COUNT 6

/**
 * @brief This is the size of the arrays ModeControlsA and ModeControlsB contained in the structure @link ControlMapping @endlink .
 */
#define MODE_MAP_COUNT 6

/**
 * @brief This is the size of the array ControlSticks contained in the structure @link ControlsModeMap @endlink .
 */
#define STICK_EVENT_COUNT 6

/**
 * @brief This is the size of the array ControlButtons contained in the structure @link ControlsModeMap @endlink .
 */
#define BUTTON_EVENT_COUNT 26

/**
 * @brief This is the size of all strings stored in the robot's firmware.
 */
#define STRING_LENGTH 20

/**
 * @brief This is the max finger count in a robot. (Jaco has 3 fingers and Mico has 2 fingers)
 */
#define JACO_FINGERS_COUNT 3

/**
 * @brief This is an error code. It means that the file you are trying to interact with does not exist
 * or is corrupted. Either way, the OS does not recognise it.
 */
#define ERROR_UNKNOWFILE 5001

/**
 * @brief This is an error code. It means that there was a memory related error. Most of the time it is because
 * the system does not have enough memory.
 */
#define ERROR_MEMORY 5002

/**
 * @brief This is an error code. It means that the function has some problem reading a file. Most of the time
 * it is because the user don't have the privileges to do it.
 */
#define ERROR_FILEREADING 5003

/**
 * @brief This represents the size of a memory page used to program the robot.
 */
const unsigned short PAGE_SIZE = 2048;

/**
 * @brief This represents the size of a page's address
 */
const int ADDRESS_PAGE_SIZE = 4;

/**
 * @brief This represents the quantity of USB packet stored in a memory page.
 */
const unsigned short PACKET_PER_PAGE_QTY = 40;

/**
 * @brief That represents the data's size of each USB packet during firmware update.
 */
const int PAGEPACKET_SIZE = 52;

/**
 * @brief That represents the size of a USB packet's header.
 */
const int USB_HEADER_SIZE = 8;

/**
 * @brief That represents the data's size of a normal USB packet.
 */
const int USB_DATA_SIZE = 56;

/**
 * @brief That represents the type of a position. If used during a trajectory, the type of position
 * will change the behaviour of the robot. For example if the position type is CARTESIAN_POSITION,
 * then the robot's end effector will move to that position using the inverse kinematics. But
 * if the type of position is CARTESIAN_VELOCITY then the robot will use the values as velocity command.
 */
enum POSITION_TYPE
{

	NOMOVEMENT_POSITION = 0,    /*!< Used for initialisation. */
	CARTESIAN_POSITION = 1,     /*!< A cartesian position described by a translation X, Y, Z and an orientation ThetaX, thetaY and ThetaZ. */
	ANGULAR_POSITION = 2,       /*!< An angular position described by a value for each actuator. */
	CARTESIAN_VELOCITY = 7,     /*!< A velo